const char*TIFFGetVersion(void){return "backdoor";}
